I'm Jezrel Jane Himbing. I just recently graduated from college,
who's currenly looking for Web Dev work, while doing some side projects/lessons.

I've been working on 3 courses via RubyLearning for since the second week of August 2012:
* Introduction to Sinatra Course(FREE)
* Git and Github Course (FREE)
* Core Ruby 35th Batch (paid training, but I'm sponsored by RubyLearning)
* Introductory course on Rack (Coming soon!)

Aside from doing exercises on RubyLearning, I'm also helping my mother to promote __<a href="http://facebook.com/vox4life">VOX4LIFE</a>__
Facebook page, which features health products by <a href="http://7349559.4life.com">4Life Research</a>, and hopefully, build an own website for it using Ruby and Sinatra/Rails.

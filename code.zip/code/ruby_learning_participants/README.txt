Cheers from Satish Talim

Cheers,
Allen

- - - - - - - -
David Loeffler

- - - - - - - -

Cheers,
ashbb

- - - - - - - -
Cheers from Budh Ram Gurung

- - - - - - - -

Hi everyone! God bless us all!

All the best,

Jezrel Jane Himbing from the Philippines

- - - - - - - -
Cheers from Arvind
.....................


Hello Satoshi. 

So glade to be a part of your github learning.

Thanks for all your work.

Douglas

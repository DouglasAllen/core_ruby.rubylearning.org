# p031motorcycletest.rb  
require_relative 'p030motorcycle'  
m = MotorCycle.new('Yamaha', 'red')  
m.start_engine  

class String  
  def write_size  
    self.size  
  end  
end  
size_writer = "Tell me my size!"  
puts size_writer.write_size   
puts size_writer.size

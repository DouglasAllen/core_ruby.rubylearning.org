class W0102FirstRubyProgram
=begin
===
  # hello.rb
  # more than one way to do hello.

  puts 'hello'
  puts "hello2"

  hello = 'hello'
  puts hello

  hello2 = "hello2"
  puts hello2

  def hello  
    'hello'  
  end 

  puts hello()

  def hello2
    "hello2"
  end

  puts hello2()
=end
  def hello_rb;end
end 


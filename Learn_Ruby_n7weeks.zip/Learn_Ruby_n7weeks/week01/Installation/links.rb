class W0101Installation
=begin
===
  #===========================================================================>
  #
  #      An Interview with the Creator of Ruby
  #       http://linuxdevcenter.com/pub/a/linux/2001/11/29/ruby.html
  #
  #      The Philosophy of Ruby
  #        http://www.artima.com/intv/ruby.html
  #
  #      Ruby Installer for Windows
  #        http://rubyinstaller.org/
  #
  #      Three Ways of Installing Ruby
  #        http://www.ruby-lang.org/en/downloads/
  #
  #      RVM ( Ruby Version Manager )
  #        https://rvm.io//rvm/
  #
  #
  #===========================================================================>
  
=end
  def links;end
end
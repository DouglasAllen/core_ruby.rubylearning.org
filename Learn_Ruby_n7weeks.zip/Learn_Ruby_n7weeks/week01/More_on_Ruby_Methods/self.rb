class W0110MoreOnRubyMethods
=begin
=== self.rb

  puts self
  main  
  
  'http://rubylearning.com/satishtalim/ruby_self.html'

  class Person
  
    def self.class_name
      puts self # Person is an instance of Class
    end
    
    def self.my_class_method
      puts "This is my own class method"
    end
    
  end

  Person.class_name
  Class
  Person.my_class_method
  This is my own class method
  
=end
 def self;end
end

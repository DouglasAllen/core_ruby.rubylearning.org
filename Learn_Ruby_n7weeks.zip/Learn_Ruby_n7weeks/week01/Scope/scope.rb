class W0107Scope
=begin
===

=end
 def scope;emd
end
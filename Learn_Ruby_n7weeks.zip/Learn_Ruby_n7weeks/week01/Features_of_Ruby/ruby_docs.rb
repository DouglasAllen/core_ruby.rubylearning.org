class W0103FeaturesOfRuby
=begin
=== ruby_docs

  'http://www.ruby-doc.org/'

=end
  def ruby_docs;end
end

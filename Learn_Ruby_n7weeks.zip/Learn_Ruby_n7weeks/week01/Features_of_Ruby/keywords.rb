class W0103FeaturesOfRuby
=begin
=== Keywords

  #  'http://www.ruby-doc.org/docs/keywords/1.9/'

=end
 def keywords;end
end


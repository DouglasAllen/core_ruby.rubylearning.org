class W0103FeaturesOfRuby
=begin
===  cheet_sheets

  #  'http://cheat.errtheblog.com/'

=end
  def cheat_sheets;end
end
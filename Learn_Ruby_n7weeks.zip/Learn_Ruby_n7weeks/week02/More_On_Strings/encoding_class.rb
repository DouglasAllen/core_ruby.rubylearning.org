# encoding: utf-8

# λ is the Greek character Lambda here
puts "λ".length     # => 1
puts "λ".bytesize   # => 2
puts "λ".encoding   # => UTF-8 



# string_methods.rb

puts String.methods.sort.join(", ")

puts String.instance_methods.sort.join(", ")

puts String.instance_methods(false).sort.join(", ")


# program.rb

unless ARGV.length == 2  
  puts "Usage: program.rb 23 45"  
  exit  
end  

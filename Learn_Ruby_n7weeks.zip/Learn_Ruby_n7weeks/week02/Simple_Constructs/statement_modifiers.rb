# statement_modifiers.rb

puts "Enrollments will now Stop" if participants > 2500

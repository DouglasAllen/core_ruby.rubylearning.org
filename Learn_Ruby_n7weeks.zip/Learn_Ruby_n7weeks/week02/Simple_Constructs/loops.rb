# loops.rb
  
var = 0  
while var < 10  
  puts var.to_s  
  var += 1  
end  

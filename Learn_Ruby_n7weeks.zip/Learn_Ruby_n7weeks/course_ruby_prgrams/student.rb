# student.rb
class Student
  
end
# p046excpvar.rb
begin
  raise 'A test exception.'
rescue Exception => e
  puts e.message
    puts e.backtrace.inspect
end
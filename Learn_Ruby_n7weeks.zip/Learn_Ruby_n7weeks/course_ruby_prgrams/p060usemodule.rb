# p060usemodule.rb
require_relative 'p058mytrig'
require_relative 'p059mymoral'
Trig.sin(Trig::PI/4)
Trig.cos(Trig::PI/4)
Moral.sin(Moral::VERY_BAD)
Moral.sin(Moral::BAD)
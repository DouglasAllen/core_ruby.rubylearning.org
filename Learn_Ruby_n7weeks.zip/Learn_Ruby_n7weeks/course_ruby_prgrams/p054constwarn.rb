# p054constwarn.rb
A_CONST = 10
A_CONST = 20
# p001hello.rb

  
puts 'Hello'

def hello(name)
  "Hello #{name}"
end

puts hello("Ruby programmers")


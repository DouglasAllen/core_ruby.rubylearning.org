# inventory.rb

puts Dir.glob('**/*').sort
#tmp = []
#tmp = Dir.glob('**/*').sort
#puts tmp


# exercise_w0105.rb
p self.class
p self

def my_string()
  'Hello World'
end

my_string = 'Hello Ruby World'

puts my_string

# p self.methods
p self.instance_variables
p self.instance_of? Object
p self.my_string

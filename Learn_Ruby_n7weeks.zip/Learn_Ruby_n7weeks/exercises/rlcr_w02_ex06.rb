# rlcr_w02_ex06.rb

=begin
c. In the following Ruby code, x gets the value nil and pqr remains an undefined local variable. Why?

if false
 x = pqr
end
puts x
puts pqr

=end

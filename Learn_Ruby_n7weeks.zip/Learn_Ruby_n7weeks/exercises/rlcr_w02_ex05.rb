# rlcr_w02_ex05.rb

=begin
THIMK

b. What happens in the following Ruby code?


x = 10
y = 20
x, y = y, x
puts x
puts y
=end

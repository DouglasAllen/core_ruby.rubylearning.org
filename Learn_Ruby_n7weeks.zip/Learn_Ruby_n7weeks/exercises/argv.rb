# argv.rb

puts ARGV.join('-')

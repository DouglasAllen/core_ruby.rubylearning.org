# dtr_convertor_patch.rb

class DTRConvertor
  def convert(usc)
    usc * 38.0
  end    
end

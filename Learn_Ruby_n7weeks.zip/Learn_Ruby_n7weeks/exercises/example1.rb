x = 2
print "This application is running okay if 2 + 2 = #{x + x}"

File.open("text.txt").each { |line| puts line } 

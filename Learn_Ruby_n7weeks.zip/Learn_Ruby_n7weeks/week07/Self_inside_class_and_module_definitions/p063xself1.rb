# p063xself1.rb  
class S  
  puts "Just started class #{self}"    
  module M  
    puts "Nested module #{self}"  
  end  
  puts "Back in the outer level of #{self}"  
end   

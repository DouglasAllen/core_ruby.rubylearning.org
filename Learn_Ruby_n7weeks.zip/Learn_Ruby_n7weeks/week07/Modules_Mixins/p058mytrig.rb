# p058mytrig.rb  
module Trig  
  PI = 3.1416  
  # class methods  
  def Trig.sin(x)  
    # ...  
  end  
  def Trig.cos(x)  
    # ...  
  end  
end   

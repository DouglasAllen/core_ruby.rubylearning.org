# p041symbolhash.rb  
people = Hash.new  
people[:nickname] = 'IndianGuru'  
people[:language] = 'Marathi'  
people[:lastname] = 'Talim'  
  
puts people[:lastname] # Talim  


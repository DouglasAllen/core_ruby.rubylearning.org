# p0411symbolhash.rb

h = {:nickname => 'IndianGuru', :language => 'Marathi', :lastname => 'Talim'}  
puts h 

# course.rb
ENV["course"] = "FORPC101"  
puts "#{ENV['course']}"  

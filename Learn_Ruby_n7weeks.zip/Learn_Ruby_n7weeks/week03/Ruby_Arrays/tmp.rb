f = ARGV[0]  
puts f   

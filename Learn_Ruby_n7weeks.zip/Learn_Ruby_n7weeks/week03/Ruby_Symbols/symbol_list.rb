symbols_array = Symbol.all_symbols 

puts symbols_array.sort.join(', ')

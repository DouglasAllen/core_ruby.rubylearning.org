# p039symbol.rb 
 
# use the object_id method of class Object  
# it returns an integer identifier for an object  
puts "string".object_id  
puts "string".object_id  
puts :symbol.object_id  
puts :symbol.object_id   
